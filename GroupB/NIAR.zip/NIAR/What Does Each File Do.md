final\_balanced\_model.py -- The balanced CNN model

generate\_full\_conectivity\_matrices.py -- Generate the FC matrices of the full brain using AAL

compensation\_trend\_analysis.py -- Analyze compensation trend only

deterioration\_trend\_analysis.py -- Analyze deterioration trend only

reho\_local\_connectivity\_analysis.py -- Generate ReHo results

sara\_compensation\_deterioration\_analysis.py - Analyze the relationship between SARA and the brain region trends

Complete\_FC\_ReHo\_Analysis.xlsx -- The data of FC and Reho results

